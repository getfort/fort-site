data "aws_ami" "ubuntu" {
  owners = ["099720109477"]
  filter {
    name   = "image-id"
    values = [var.ami_id]
  }
  filter {
    name   = "name"
    values = ["ubuntu/images/hvm-ssd-gp3/ubuntu-noble-24.04-amd64-server-*"]
  }
  filter {
    name   = "architecture"
    values = ["x86_64"]
  }
}

data "aws_subnet" "this" {
  id = var.subnet_id
}

module "bootstrap" {
  source         = "../shared"
  docker_version = var.docker_version
  config = {
    cloud          = "aws"
    region         = var.region
    secret_id      = var.bootstrap_secret_arn
    secret_version = var.bootstrap_secret_version
    fort           = var.fort
  }
}

resource "aws_security_group" "fort" {
  name_prefix = "${var.name}-"
  description = "Fort console and optional SSH only from configured sources"
  vpc_id      = var.vpc_id
}
resource "aws_vpc_security_group_ingress_rule" "console" {
  for_each          = var.console_cidrs
  security_group_id = aws_security_group.fort.id
  ip_protocol       = "tcp"
  from_port         = 7451
  to_port           = 7451
  cidr_ipv4         = each.value
}
resource "aws_vpc_security_group_ingress_rule" "ssh" {
  for_each          = var.ssh_cidrs
  security_group_id = aws_security_group.fort.id
  ip_protocol       = "tcp"
  from_port         = 22
  to_port           = 22
  cidr_ipv4         = each.value
}
resource "aws_vpc_security_group_egress_rule" "outbound" {
  security_group_id = aws_security_group.fort.id
  ip_protocol       = "-1"
  cidr_ipv4         = "0.0.0.0/0"
}

resource "aws_iam_role" "vm" {
  name_prefix = "${var.name}-"
  assume_role_policy = jsonencode({
    Version   = "2012-10-17"
    Statement = [{ Effect = "Allow", Action = "sts:AssumeRole", Principal = { Service = "ec2.amazonaws.com" } }]
  })
}
resource "aws_iam_role_policy" "bootstrap" {
  role = aws_iam_role.vm.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = concat([
      { Effect = "Allow", Action = ["secretsmanager:GetSecretValue"], Resource = var.bootstrap_secret_arn }
      ], var.secret_kms_key_arn == null ? [] : [
      { Effect = "Allow", Action = ["kms:Decrypt"], Resource = var.secret_kms_key_arn,
      Condition = { StringEquals = { "kms:ViaService" = "secretsmanager.${var.region}.amazonaws.com" } } }
    ])
  })
}
resource "aws_iam_instance_profile" "vm" {
  name_prefix = "${var.name}-"
  role        = aws_iam_role.vm.name
}

resource "aws_eip" "console" {
  domain = "vpc"
  tags   = { Name = var.name }
}
resource "aws_instance" "fort" {
  ami                         = data.aws_ami.ubuntu.id
  instance_type               = var.instance_type
  subnet_id                   = var.subnet_id
  vpc_security_group_ids      = [aws_security_group.fort.id]
  iam_instance_profile        = aws_iam_instance_profile.vm.name
  key_name                    = var.key_name
  associate_public_ip_address = true
  disable_api_termination     = true
  user_data_base64            = base64gzip(module.bootstrap.script)
  user_data_replace_on_change = true
  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required"
    http_put_response_hop_limit = 1
    instance_metadata_tags      = "disabled"
  }
  root_block_device {
    volume_type           = "gp3"
    volume_size           = var.disk_size_gb
    encrypted             = true
    delete_on_termination = false
  }
  tags = { Name = var.name }
  lifecycle {
    prevent_destroy = true
    precondition {
      condition     = data.aws_subnet.this.vpc_id == var.vpc_id
      error_message = "subnet_id must belong to vpc_id."
    }
    precondition {
      condition     = length(var.ssh_cidrs) == 0 || try(trimspace(var.key_name) != "", false)
      error_message = "SSH ingress needs an existing EC2 key_name."
    }
    precondition {
      condition     = length(base64gzip(module.bootstrap.script)) * 3 / 4 <= 16384
      error_message = "Compressed bootstrap exceeds EC2's 16 KiB user-data limit."
    }
    precondition {
      condition     = split(":", var.bootstrap_secret_arn)[3] == var.region
      error_message = "The bootstrap secret must be in the VM's region."
    }
  }
  depends_on = [aws_iam_role_policy.bootstrap, aws_vpc_security_group_egress_rule.outbound]
}
resource "aws_eip_association" "console" {
  allocation_id = aws_eip.console.id
  instance_id   = aws_instance.fort.id
}
resource "aws_route53_record" "console" {
  count   = var.dns_zone_id == null ? 0 : 1
  zone_id = var.dns_zone_id
  name    = var.fort.hostname
  type    = "A"
  ttl     = 300
  records = [aws_eip.console.public_ip]
}
