output "console_url" {
  value = module.bootstrap.console_url
}
output "oidc_callback_url" {
  value = module.bootstrap.oidc_callback_url
}
output "public_ip" {
  value = aws_eip.console.public_ip
}
output "instance_id" {
  value = aws_instance.fort.id
}
output "retained_disk_id" {
  value = one(aws_instance.fort.root_block_device).volume_id
}
output "readiness" {
  value = "Infrastructure creation is not guest readiness. Check EC2 console output for 'Fort bootstrap ready', then open console_url and sign in."
}
