variable "region" {
  description = "AWS region containing the subnet, AMI and bootstrap secret."
  type        = string
}
variable "vpc_id" {
  description = "Existing VPC; the module never edits its routes or NACLs."
  type        = string
}
variable "subnet_id" {
  description = "Existing subnet with internet routing for this public-address VM."
  type        = string
}
variable "ami_id" {
  description = "Pinned Canonical Ubuntu 24.04 x86_64 AMI in this region."
  type        = string
}
variable "instance_type" {
  description = "x86_64 VM size; 4 vCPU/16 GiB recommended to start."
  type        = string
  default     = "m7i.xlarge"
}
variable "key_name" {
  description = "Existing EC2 key pair; required only when ssh_cidrs is nonempty."
  type        = string
  default     = null
}
variable "bootstrap_secret_arn" {
  description = "Existing same-account, same-region Secrets Manager secret containing the documented JSON."
  type        = string
  validation {
    condition     = can(regex("^arn:aws:secretsmanager:[a-z0-9-]+:[0-9]{12}:secret:[A-Za-z0-9/_+=.@-]+$", var.bootstrap_secret_arn))
    error_message = "Supply the full Secrets Manager secret ARN in commercial AWS."
  }
}
variable "bootstrap_secret_version" {
  description = "Immutable Secrets Manager VersionId; never AWSCURRENT or latest."
  type        = string
  validation {
    condition     = can(regex("^[A-Za-z0-9-]{32,64}$", var.bootstrap_secret_version))
    error_message = "Supply an exact Secrets Manager version ID (32–64 characters)."
  }
}
variable "secret_kms_key_arn" {
  description = "Optional customer-managed KMS key encrypting that secret; no wildcard keys."
  type        = string
  default     = null
  validation {
    condition     = var.secret_kms_key_arn == null ? true : can(regex("^arn:aws:kms:[a-z0-9-]+:[0-9]{12}:key/[a-f0-9-]{36}$", var.secret_kms_key_arn))
    error_message = "Use one full customer-managed KMS key ARN; wildcard keys are refused."
  }
}
variable "dns_zone_id" {
  description = "Optional existing public Route 53 hosted zone; null means manage DNS yourself."
  type        = string
  default     = null
}
