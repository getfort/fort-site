# Fort customer installation on AWS

Start with the [customer deployment guide](../README.md), which covers binary delivery,
TLS/secret preparation, company sign-in, initial administrator, readiness and maintenance.
Copy `terraform.tfvars.example` to `terraform.tfvars` and replace every example value.

```sh
terraform init
terraform plan -out=install.tfplan
terraform apply install.tfplan
terraform output console_url
```

`terraform apply` creates infrastructure; it does not wait for the guest installation.
Do not open it to the world to fix a connectivity problem. The console is HTTPS on 7451;
its API on 7443 stays loopback-only. SSH ingress defaults off. Select the existing
maintenance `key_name` at initial launch if using SSH; then enable only `ssh_cidrs`
when needed. Adding or changing the key later requires a protected VM replacement.

Provider versions and checksums are committed. The root module is intended to be copied
or used from a repository checkout together with `../shared`; do not copy this folder alone.
A new deployment needs its own state and name. The VM blocks destruction/replacement,
and its root disk is retained. Read the shared guide before changing or deleting it.
