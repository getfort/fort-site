# Install Fort in AWS or Google Cloud

Fill in an example, apply Terraform, then open Fort's existing operator console and sign
in with your company account. This installs one Ubuntu 24.04 x86_64 VM, not a cluster.
AWS uses an existing public subnet; GCP creates a dedicated VPC/subnet so broad rules in
the default network do not apply. Azure and Oracle templates are not included yet.

The console uses HTTPS on **7451**. Fort's API stays on `127.0.0.1:7443`; its internal
services are not published. Your policy still controls agents through OpenShell and
Warden. These templates add no login method or permission bypass.

## Prepare once

You need Terraform 1.9 or later (below 2.0), cloud credentials allowed to create the
listed resources, a reachable DNS hostname, a certificate/key for that hostname, and
OIDC clients registered with your identity provider. SSH is optional and defaults off.

**Binaries:** release packaging M20a has not shipped. There is no assumed public release.
Supply direct HTTPS URLs and independent SHA-256 hashes for `fort` and `fortd`, from
the same qualified Linux x86_64 build. Build the production console before the daemon
(`cargo xtask console build`, then `cargo build --release --locked -p fort -p fortd` on
Linux). A daemon without embedded console assets fails readiness. Use a Linux builder
or the release pipeline; Mac binaries will not run here. Hashes must come from your
trusted build, separately from the download server.

Publish the open-source binaries at operator-controlled URLs without credentials,
query parameters or redirects; the examples use placeholders that must be replaced.
OpenShell itself is installed and checked by the binary's embedded manifest through
`fort up`. Never use `latest`, disable hash checks or override failed prerequisites to
make an unsupported build start. An unsigned development build is not a signed release.

**TLS and secrets:** create one existing AWS Secrets Manager or GCP Secret Manager secret
with this JSON structure, using the cloud console's protected input or your existing
secret-management process. Use the certificate's full PEM chain and an unencrypted PEM
private key. The certificate must match the hostname and remain valid for at least a day.
It must chain to a browser-trusted CA or your team's installed corporate CA.

```json
{
  "tls_certificate": "-----BEGIN CERTIFICATE-----\n...full chain...\n-----END CERTIFICATE-----\n",
  "tls_private_key": "-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n",
  "console_oidc_client_secret": "optional: omit this key for a public PKCE client",
  "step_up_client_secret": "optional: omit this key unless the device client needs it"
}
```

The two client-secret keys are optional; remove unused keys rather than setting them to
empty strings. Never put the actual JSON, private key or secret values into tfvars,
Terraform data sources, shell history, command arguments or VM metadata. Pass only the
secret reference and its exact version. The VM fetches it at boot, using an identity
that can read that secret only (and its explicit KMS key in AWS, when applicable).
GCP's binding is scoped to the secret, not the whole project. GCP's cloud-platform OAuth
scope does not grant permissions beyond IAM. Cloud administrators and people with VM
administrative access remain trusted; do not grant access to an untrusted workload.

## Register company sign-in

Select the hostname before registration. For `fort.company.com`, the browser client's
exact redirect URI is:

```text
https://fort.company.com:7451/auth/callback
```

The underlying issuer must support OIDC discovery and the device grant for CLI sign-in
and approval step-up. The console uses authorization code with PKCE. These are existing
Fort flows; a console session alone cannot finish an approval.

- With a public client supporting both grants, use that client as `oidc_client_id` and
  omit `console_oidc_client_id` and the browser secret.
- If the issuer needs separate clients, set the device client as `oidc_client_id`, the
  web client as `console_oidc_client_id`, and its secret in the bootstrap secret when
  required. Google requires a Web application client and a separate TVs and Limited
  Input devices client; put the latter's required secret in `step_up_client_secret`.
- `step_up_client_id` is optional when the device client is already `oidc_client_id`.
- Fort's installer uses issuer name `default`. `admin_group` binds `default/<group>`
  globally to `admin`. The issuer must include that exact group in the configured
  `oidc_groups_claim` (default `groups`). Alternatively specify one immutable
  `admin_subject` (the issuer's `sub`, not an email) and omit `admin_group`.

Creating the IdP clients is a customer prerequisite. This module does not administer
your IdP or give everyone in an email domain admin. Use your IdP's guide to enable the
required grants, claims and client assignments. For issuers without group claims, the
explicit OIDC subject alternative provides the initial admin.

## Configure the cloud

Copy the whole `customer` directory or use it in a repository checkout; both cloud
modules depend on `../shared`. Each environment needs its own state and name. State,
plans and real tfvars are ignored by Git; use your organization's access-controlled,
encrypted remote Terraform backend for a shared installation.

**AWS:** select an existing VPC/public subnet with an internet-gateway route and working
DNS. Supply a pinned Canonical Ubuntu 24.04 amd64 AMI in that region (owner
`099720109477`), a Secrets Manager ARN in that account/region and its immutable VersionId.
The module creates an EC2 instance, EIP, dedicated security group and a narrowly scoped
instance role/profile. An optional existing Route 53 public zone gets an A record.
When using a customer-managed secret encryption key, supply its full key ARN and allow
the created role in the key's policy. If SSH is your maintenance path, set `key_name`
to an existing EC2 key pair at the **initial launch**, while leaving `ssh_cidrs` empty
until access is needed. Later change only the approved source CIDRs. Adding or changing
`key_name` after launch requires VM replacement, which `prevent_destroy` blocks.
Choose and qualify a different administration path before launch if you omit the key;
this module does not provision an alternative such as SSM. Review subnet NACLs and
organization policies.

**GCP:** use a billing-enabled project; select a region and a zone within it. Supply an
exact `ubuntu-2404-noble-amd64-vDATE` image from `ubuntu-os-cloud`, an existing same-project
Secret Manager secret name and numeric version. The module enables Compute, IAM and
Secret Manager without disabling them on teardown, creates a new VPC/subnet, static
external IP, VM and secret-reader service account. It optionally writes an A record in
an existing Cloud DNS public zone. The default subnet is `10.80.0.0/24`; avoid overlap
with Docker and backend networks. Private backends in another VPC require your approved
peering/routing, managed outside this module. Review inherited organization firewall
policies; the module cannot validate every policy affecting the project.

`console_cidrs` must be the IPv4 source ranges that actually reach the VM (usually your
corporate/public egress addresses). `0.0.0.0/0` and an empty list are refused. Native DNS
is optional: if you omit its zone, create the hostname's A record using the returned
`public_ip`. Keep any proxy disabled unless separately configured and reviewed; these
modules serve the browser directly and do not depend on Cloudflare or a hosted backend.
Do not add an AAAA record: these modules provide IPv4 connectivity only.

The defaults are 4 vCPU, 16 GiB and a 120 GiB encrypted root disk. Review current cloud
pricing for the region, VM, disk, public IP, DNS and secret access before applying.
The templates make no fixed-cost or high-availability promise; this is a single VM.

## Deploy and check readiness

Choose `aws` or `gcp`, authenticate through your usual cloud profile/ADC/workload identity,
then run from that folder:

```sh
cp terraform.tfvars.example terraform.tfvars
# Edit every required/example value. Do not paste secret values here.
terraform init
terraform plan -out=install.tfplan
terraform apply install.tfplan
terraform output console_url
terraform output oidc_callback_url
```

Terraform completion means the infrastructure exists. Guest installation continues
afterward and can fail independently. Before installation, the bootstrap preserves an existing
nonempty `/etc/hostname`; if missing or empty, it records the validated current kernel
hostname there as a root-owned 0644 file without changing the kernel hostname. The
bootstrap verifies both binary hashes before executing either. It installs Fort once with a loopback API and no console to create
service accounts, writes the protected TLS/client-secret files, then enables the console
through `fort up`. It binds the chosen admin through root's existing local bootstrap
credential and verifies the exact binding. It writes `admin-bound` only after that check,
then requires `fort doctor`, both active services and served console assets before `done`.
No token is printed; Fort's temporary bootstrap service account keeps its existing
24-hour lifetime and cannot complete human approvals.

In the cloud console, look at **EC2 system/console output** or **GCP serial-port output**
for `Fort bootstrap ready: https://...`. A failure prints only the stage, never command
output or credentials. Serial output does not replace a browser sign-in check. If serial
output is unavailable, enable restricted SSH temporarily or use your approved cloud
administration path to run these checks:

```sh
sudo test -f /var/lib/fort-onboarding/done
sudo fort doctor
sudo systemctl is-active fortd openshell-gateway
```

GCP OS Login requires your operator to hold `roles/compute.osAdminLogin` and
`roles/iam.serviceAccountUser` on the VM's service account; console/CLI access can also
need project read permissions. The module creates no human IAM bindings. Enable SSH only
from the necessary CIDRs (`ssh_cidrs`); GCP IAP additionally needs its documented IAM role
and `35.235.240.0/20` as the SSH source range. Remove temporary SSH ingress afterward.

Open the HTTPS console URL from an allowed network. Check the certificate without a
browser exception, complete company sign-in, and verify the intended admin has access
to the Agents/Access pages. An unassigned account must not gain admin. Check that an
approval still starts its separate human step-up. Confirm externally that 7443 and the
internal ports are closed and that a disallowed source cannot reach 7451 or SSH.
These fresh-VM/browser checks are manual acceptance, not claimed by offline tests.

## Next: deploy the agent and its tool servers

This template prepares the Fort VM, console and initial administrator. Prepare your
agent image and the tool-server images it will call before deploying the workload.
Move backend operations and credentials out of the agent and into those tool servers.

Fort already runs declared tool servers as separate Docker containers on the same VM,
outside every sandbox. Declare each ToolServer image, listen port/path, backend hosts,
credential references, tool names and health check in the policy repo. Grant access
through the agent's `tool_access` policy and configure its Streamable HTTP MCP client
to read the injected `FORT_TOOL_<SERVER>_URL` variable, such as `FORT_TOOL_OPS_URL`.

Create the project, register providers and tool secrets through an authorized CLI
context, then validate and apply the complete policy repo. Fort pulls, starts and
maintains the tool containers. Enable the template's restricted SSH option if you
need initial CLI access on the VM; keep the API private. The bootstrap cloud secret
is for installation TLS/sign-in, while backend credentials belong in Fort's tool
secret store. Private-backend routing and backend permissions are prerequisites.

A running sandbox is not the final acceptance check. Confirm the tool server is
healthy and the agent can initialize MCP, list its permitted tools and complete one
allowed read-only call to the backend, with its decision in the ledger. Investigate
tool health, MCP client configuration and policy before widening network access.
See the [tool-server design](../../../docs/design/10-tool-servers-and-relay.md)
and the [policy schema](../../../docs/design/01-policy-language.md) for complete fields.

## Retry, maintain and remove

An unchanged failed installation can be retried as root with:

```sh
sudo python3 /var/lib/fort-onboarding/bootstrap.py
```

It suppresses subprocess and cloud error bodies to keep secrets out of logs. Use the
reported stage to investigate: confirm direct artifact access and hashes; cloud IAM and
secret version; TLS files/hostname; OIDC discovery; or the initial admin binding. Run
`sudo fort doctor` for Fort diagnostics. Do not add tracing or print secret payloads.
If a retry occurs after the bootstrap token expired and **before** `admin-bound` exists,
reissue into **root’s** credential store, matching the bootstrap’s execution environment:

```sh
sudo env -u SUDO_UID -u SUDO_GID -u SUDO_USER HOME=/root /usr/local/bin/fort up --reissue-bootstrap-token
```

Clearing the sudo caller variables makes Fort deliver the token to root rather than the
SSH operator; setting `HOME` alone does not change Fort’s invoking-user selection.
Check the installation settings first, then retry the Python bootstrap. An already
verified admin stage is retained across
a later readiness failure. Never reissue tokens as a generic response to unrelated errors.

The stored non-secret configuration and stage markers are compared before retry. A new
configuration is refused; a successful unchanged bootstrap is a no-op. Updating tfvars
is not an upgrade mechanism. AWS user-data changes request replacement (blocked); GCP
metadata changes do not apply new Fort settings to an already initialized installation.

For certificate renewal or client-secret rotation, use a planned maintenance window:
make a new cloud secret version, retrieve it through your approved root-only process,
validate it, atomically replace only the relevant files under `/etc/fort/customer`, and
preserve `fort` ownership, certificate mode 0644 and key/client-secret mode 0600.
For a rotated device client secret, explicitly reinstall its copy with
`sudo fort up --step-up-client-secret-file /etc/fort/customer/device.secret`; plain
`fort up` keeps the old installed copy. For certificate or console-client secret changes,
run `sudo fort up` using its recorded settings. Then explicitly run
`sudo systemctl restart fortd` so the new TLS and browser-client secret are loaded;
unchanged config paths alone do not trigger a restart. Finally run `sudo fort doctor`,
check each service and test browser sign-in/step-up. A fortd restart ends browser sessions
and governed calls fail closed during the restart. The version pin and initial bootstrap metadata remain an
installation record; rotation is explicit maintenance, not a replay of initial admin
bootstrap. Removing a client secret also needs the corresponding Fort configuration
change; do not silently delete its file. No unattended renewal or upgrades are installed.

Before replacement, create and verify a Fort backup, copy it off the VM and test the
restore procedure. Preserve both databases and all key/configuration material. The VM
has Terraform `prevent_destroy` and cloud deletion protection. Root disks are encrypted
and configured **not** to auto-delete with the VM; a retained disk alone is not a backup.
Replacement and destruction are deliberately blocked: review a plan, explicitly remove
the protections in your reviewed copy, and disable cloud termination/deletion protection
before a deliberate deletion. A GCP protection change must be applied before deletion.
Record the EBS volume or GCP disk identity first and delete retained disks separately
only after confirming evidence retention and off-host backups. Stopping the VM still
incurs disk/IP costs. Do not suspend a running Fort VM (M0 clock/credential finding).

## Offline verification

```sh
bash deploy/terraform/customer/tests/check.sh
```

This uses mocked Terraform providers, Python fakes and shell checks. It never creates
cloud resources. The full repository checks remain `cargo xtask check` and
`cargo nextest run`. Actual VM installation, cloud firewall policy, DNS, browser trust,
IdP claims and sign-in/step-up need the manual acceptance above on each target cloud.
