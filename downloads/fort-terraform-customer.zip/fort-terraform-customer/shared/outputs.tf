output "script" {
  description = "Root bootstrap; contains code and non-secret configuration only."
  value       = local.script
}

output "console_url" {
  value = "https://${var.config.fort.hostname}:7451"
}

output "oidc_callback_url" {
  value = "https://${var.config.fort.hostname}:7451/auth/callback"
}
