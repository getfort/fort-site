terraform {
  required_version = ">= 1.9, < 2.0"
}

locals {
  script = templatefile("${path.module}/bootstrap.sh.tftpl", {
    config_b64     = base64encode(jsonencode(var.config))
    python_b64     = filebase64("${path.module}/bootstrap.py")
    docker_version = var.docker_version
  })
}
