terraform {
  required_version = ">= 1.9, < 2.0"
}

locals {
  // The additions below render to nothing (and the entry point to bootstrap.py) when
  // unused, so the AWS and GCP scripts stay byte-for-byte what they were; the golden hashes in
  // tests/render_golden.tftest.hcl prove it.
  extra_files_block = join("", [for name, content in var.extra_files :
  "\nprintf '%s' '${content}' | base64 -d > /var/lib/fort-onboarding/${name}\nchmod 0700 /var/lib/fort-onboarding/${name}"])
  extra_packages = join("", [for p in var.extra_packages : " ${p}"])
  script = templatefile("${path.module}/bootstrap.sh.tftpl", {
    config_b64        = base64encode(jsonencode(var.config))
    python_b64        = filebase64("${path.module}/bootstrap.py")
    docker_version    = var.docker_version
    extra_files_block = local.extra_files_block
    extra_packages    = local.extra_packages
    entrypoint        = var.entrypoint
    preamble          = var.preamble
  })
}
