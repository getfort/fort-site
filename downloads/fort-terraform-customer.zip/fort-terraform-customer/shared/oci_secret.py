"""Read the Fort bootstrap secret from OCI Vault with the VM's instance principal (M15g).

Standard library plus the image's `openssl` only, and only Oracle's documented sequence:
instance metadata, a federation call for a session token, a signed secret-bundle read. Every
call but the link-local metadata read is HTTPS with the system CAs. No key, token, certificate
body or secret value is ever written to a file, an argument, a log or an error message: keys
stay in memory and reach `openssl` on a pipe.
"""

import base64
import hashlib
import json
import os
import re
import subprocess
import time
import urllib.error
import urllib.request
from email.utils import formatdate

IMDS = "http://169.254.169.254/opc/v2/"
RETRY_FOR = 600          # seconds: the IAM first-boot race, never longer
MARGIN = 60              # a token must outlive the fetch by this much
NOT_AUTHORISED = (401, 403, 404)


class OciError(Exception):
    """A failure of the sign-in; carries only the stage name and a fixed message."""

    def __init__(self, stage, message):
        super().__init__(message)
        self.stage = stage


class NotAuthorised(Exception):
    pass


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def default_open_url(request):
    return urllib.request.build_opener(_NoRedirect()).open(request, timeout=30)


def signing_string(method, target, headers):
    """The string Oracle's HTTP signature covers: the request target, then each header."""
    lines = ["(request-target): " + method.lower() + " " + target]
    lines += [name + ": " + value for name, value in headers]
    return "\n".join(lines)


def authorization(key_id, header_names, signature_b64):
    return ('Signature version="1",keyId="' + key_id + '",algorithm="rsa-sha256",headers="' +
            header_names + '",signature="' + signature_b64 + '"')


def jwt_claims(token):
    parts = token.split(".")
    if len(parts) != 3:
        raise ValueError("not a token")
    payload = parts[1] + "=" * (-len(parts[1]) % 4)
    claims = json.loads(base64.urlsafe_b64decode(payload))
    if not isinstance(claims, dict):
        raise ValueError("not a token")
    return claims


def _openssl(args, data=b"", key=None):
    """Run `openssl`; a private key goes on a pipe and the command names `/dev/fd/N`."""
    reader = writer = None
    try:
        kwargs = {}
        if key is not None:
            reader, writer = os.pipe()
            os.write(writer, key)
            os.close(writer)
            writer = None
            args = [("/dev/fd/%d" % reader) if a == "{key}" else a for a in args]
            kwargs["pass_fds"] = (reader,)
        done = subprocess.run(["openssl"] + args, input=data, capture_output=True, **kwargs)
        if done.returncode != 0:
            raise OciError("openssl", "an openssl step failed")
        return done.stdout
    finally:
        for fd in (reader, writer):
            if fd is not None:
                os.close(fd)


def _pem_body(pem):
    return "".join(line for line in pem.decode().splitlines() if line and "-----" not in line)


def _read(open_url, request, limit):
    with open_url(request) as response:
        data = response.read(limit + 1)
    if len(data) > limit:
        raise OciError("response", "an answer was too large")
    return data


def _classify(error):
    """HTTP 401, 403 or 404 with a not-authorised (or not-authenticated) code is the one retried
    answer."""
    if isinstance(error, urllib.error.HTTPError) and error.code in NOT_AUTHORISED:
        try:
            code = str(json.loads(error.read(4096)).get("code", ""))
        except Exception:
            code = ""
        if code.startswith(("NotAuthor", "NotAuthent")):
            return NotAuthorised()
    return None


def _imds(open_url, path, limit=16384):
    request = urllib.request.Request(IMDS + path, headers={"Authorization": "Bearer Oracle"})
    return _read(open_url, request, limit)


def _location(open_url, cfg):
    try:
        info = json.loads(_imds(open_url, "instance/regionInfo"))
        region, realm = info["regionIdentifier"], info["realmDomainComponent"]
    except OciError:
        raise
    except Exception:
        raise OciError("region", "the instance metadata did not name its region") from None
    if (not re.fullmatch(r"[a-z0-9-]+", region or "") or
            not re.fullmatch(r"[a-z0-9]([a-z0-9.-]*[a-z0-9])?", realm or "") or ".." in realm or
            "." not in realm):
        raise OciError("region", "the instance metadata named an unexpected region or realm")
    if region != cfg.get("region"):
        raise OciError("region", "the instance is not in the configured region")
    return region, realm


def _identity(open_url):
    try:
        cert = _imds(open_url, "identity/cert.pem")
        key = _imds(open_url, "identity/key.pem")
        intermediate = _imds(open_url, "identity/intermediate.pem")
    except OciError:
        raise
    except Exception:
        raise OciError("identity", "the instance identity could not be read") from None
    subject = _openssl(["x509", "-noout", "-subject", "-nameopt", "RFC2253"], cert).decode()
    match = re.search(r"opc-tenant:(ocid1\.tenancy\.[A-Za-z0-9._-]+)", subject)
    if not match:
        raise OciError("certificate", "the instance certificate names no tenancy")
    fingerprint = _openssl(["x509", "-noout", "-fingerprint", "-sha1"], cert).decode()
    fingerprint = fingerprint.split("=", 1)[1].strip().upper()
    return cert, key, intermediate, match.group(1), fingerprint


def _signed(clock, method, host, target, key, key_id, extra, body=None):
    """A request signed as Oracle documents; `extra` are the body headers of a POST."""
    date = formatdate(clock(), usegmt=True)
    headers = [("date", date), ("host", host)] + extra
    names = "(request-target) " + " ".join(n for n, _ in headers)
    signature = _openssl(["dgst", "-sha256", "-sign", "{key}"],
                         signing_string(method, target, headers).encode(), key=key)
    request = urllib.request.Request("https://" + host + target, data=body, method=method)
    for name, value in headers:
        request.add_header(name, value)
    request.add_header("Accept", "application/json")
    request.add_header("Authorization", authorization(
        key_id, names, base64.b64encode(signature).decode()))
    return request


def _attempt(cfg, open_url, clock, region, realm, identity):
    cert, instance_key, intermediate, tenancy, fingerprint = identity
    session_key = _openssl(["genrsa", "2048"])
    session_pub = _openssl(["rsa", "-pubout"], session_key)
    body = json.dumps({"certificate": _pem_body(cert), "publicKey": _pem_body(session_pub),
                       "intermediateCertificates": [_pem_body(intermediate)]},
                      separators=(",", ":")).encode()
    digest = base64.b64encode(hashlib.sha256(body).digest()).decode()
    host = "auth." + region + "." + realm
    federation = _signed(
        clock, "POST", host, "/v1/x509", instance_key, tenancy + "/fed-x509/" + fingerprint,
        [("content-length", str(len(body))), ("content-type", "application/json"),
         ("x-content-sha256", digest)], body)
    answer = json.loads(_read(open_url, federation, 16384))
    token = answer.get("token")
    try:
        claims = jwt_claims(token)
    except Exception:
        raise OciError("token", "the session token was not valid") from None
    exp = claims.get("exp")
    if not isinstance(exp, (int, float)) or exp < clock() + MARGIN:
        raise OciError("token", "the session token was expired")
    if "tenant" in claims and claims["tenant"] != tenancy:
        raise OciError("token", "the session token names another tenancy")
    secret, version = cfg["secret_id"], str(cfg["secret_version"])
    if not re.fullmatch(r"ocid1\.[a-z0-9._-]+", secret) or not re.fullmatch(r"[0-9]+", version):
        raise OciError("secret", "the secret reference is not valid")
    vault = _signed(clock, "GET", "secrets.vaults." + region + ".oci." + realm,
                    "/20190301/secretbundles/" + secret + "?versionNumber=" + version,
                    session_key, "ST$" + token, [])
    bundle = json.loads(_read(open_url, vault, 131072))["secretBundleContent"]
    if bundle.get("contentType") != "BASE64":
        raise OciError("secret", "the secret content was not base64")
    return json.loads(base64.b64decode(bundle["content"], validate=True))


def fetch_secret_bundle(cfg, open_url=default_open_url, clock=time.time, sleep=time.sleep):
    """The bootstrap secret as a dict. A not-authorised answer is retried with a backoff for at
    most ten minutes (the dynamic group and policy take a short while to apply after the
    instance exists); every other failure stops at once."""
    region, realm = _location(open_url, cfg)
    identity = _identity(open_url)
    started, delay = clock(), 5
    while True:
        try:
            return _attempt(cfg, open_url, clock, region, realm, identity)
        except OciError:
            raise
        except Exception as error:
            if _classify(error) is None:
                raise OciError("fetch", "reading the secret failed") from None
        if clock() - started + delay > RETRY_FOR:
            raise OciError(
                "authorisation",
                "not authorised to read the bootstrap secret after ten minutes; check the "
                "dynamic group " + str(cfg.get("oci_dynamic_group")) + " and the policy " +
                str(cfg.get("oci_policy")))
        sleep(delay)
        delay = min(delay * 2, 60)
