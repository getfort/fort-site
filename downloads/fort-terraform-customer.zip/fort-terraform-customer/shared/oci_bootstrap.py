"""OCI entry point (M15g): the unchanged shared bootstrap with an OCI secret fetch.

`bootstrap.py` is not edited: it is embedded whole in every cloud's boot script, so a change
would change the AWS and GCP user data. This file imports it, replaces only the secret fetch
for `oci`, opens the console port in the host firewall and runs it.
"""

import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import bootstrap  # noqa: E402
import oci_secret  # noqa: E402

PORT = "7451"
RULE = ["-p", "tcp", "--dport", PORT, "-m", "conntrack", "--ctstate", "NEW", "-j", "ACCEPT"]


class OciHost(bootstrap.Host):
    """The shared host; only the `oci` secret fetch differs."""

    def secret(self, cfg):
        if cfg.get("cloud") == "oci":
            try:
                return oci_secret.fetch_secret_bundle(cfg, open_url=bootstrap.open_url)
            except oci_secret.OciError as error:
                # bootstrap.main prints only the stage; this message is fixed text (never an
                # upstream body, key or token) and names the dynamic group and policy to check.
                print("Fort bootstrap: OCI secret read failed at " + error.stage + ": " + str(error),
                      file=sys.stderr)
                raise
        return super().secret(cfg)


def _run(args):
    done = subprocess.run(args, capture_output=True, text=True)
    return done.returncode, done.stdout


def open_console_port(run=_run):
    """Oracle's Ubuntu images reject inbound ports in the host itself, beyond the network rules.
    Add exactly one rule for the console port, ahead of the image's reject rule and only if it
    is absent, and always save the set so it survives a reboot. Nothing else is touched: no other port, chain or policy."""
    if run(["iptables", "-C", "INPUT"] + RULE)[0] != 0:
        code, listing = run(["iptables", "-S", "INPUT"])
        position, seen = 1, 0
        if code == 0:
            for line in listing.splitlines():
                if line.startswith("-A INPUT"):
                    seen += 1
                    if "-j REJECT" in line or "-j DROP" in line:
                        position = seen
                        break
        if run(["iptables", "-I", "INPUT", str(position)] + RULE)[0] != 0:
            raise RuntimeError("host firewall")
    # Always save, even when the rule is already live: an earlier run may have inserted it and
    # failed to save, and an unsaved rule is gone after a reboot.
    if run(["netfilter-persistent", "save"])[0] != 0:
        raise RuntimeError("host firewall")


def main():
    try:
        open_console_port()
    except Exception:
        print("Fort bootstrap failed during host firewall; no ready marker was written. "
              "See the customer deployment README.", file=sys.stderr)
        return 1
    bootstrap.Host = OciHost
    return bootstrap.main()


if __name__ == "__main__":
    sys.exit(main())
