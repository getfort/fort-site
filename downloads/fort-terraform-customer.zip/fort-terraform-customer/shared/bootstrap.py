#!/usr/bin/env python3
"""Install Fort using existing CLI surfaces. Only non-secret settings enter metadata."""

import base64
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import socket
import ssl
import subprocess
import sys
import tempfile
import urllib.request
from urllib.parse import urlsplit

MAX_BINARY = 512 * 1024 * 1024


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise RuntimeError("redirect refused; configure a direct HTTPS artifact URL")


def validate_url(url):
    u = urlsplit(url)
    if (u.scheme != "https" or not u.hostname or u.username or u.password
            or u.query or u.fragment):
        raise RuntimeError("a direct HTTPS URL without credentials or query is required")


def open_url(request):
    return urllib.request.build_opener(NoRedirect()).open(request, timeout=30)


def admin_identity(fort):
    group, subject = fort["admin_group"], fort["admin_subject"]
    if bool(group) == bool(subject):
        raise RuntimeError("configure exactly one admin group or immutable OIDC subject")
    return (("--group", "default/" + group, "group", group) if group else
            ("--oidc", "default/" + subject, "oidc", subject))


def has_binding(bindings, kind, value):
    for b in bindings:
        ref = b.get("subject", {}).get(kind, {})
        matches = (ref == value if kind == "userId" else
                   ref.get("issuerName") == "default" and ref.get("name") == value)
        if (b.get("role") == "admin" and b.get("scope") == "global" and not b.get("stale")
                and matches):
            return True
    return False


def principal_id(principals, issuer, subject):
    ids = [p["id"] for p in principals if p.get("id") and not p.get("disabled")
           and p.get("kind") == "PRINCIPAL_KIND_USER"
           and p.get("oidcIssuer") == issuer and p.get("oidcSubject") == subject]
    return ids[0] if len(ids) == 1 else None


class Host:
    def __init__(self, root=Path("/")):
        self.root = root
        self.work = root / "var/lib/fort-onboarding"
        self.etc = root / "etc/fort/customer"
        self.stage = "configuration"

    def path(self, name):
        return self.work / name

    def run(self, args, timeout=1800):
        # Do not leak upstream errors, command output or secrets through exception strings.
        result = subprocess.run(list(map(str, args)), capture_output=True, text=True,
                                timeout=timeout, stdin=subprocess.DEVNULL, env={"HOME": "/root", "PATH": os.defpath +
                                ":/usr/local/bin:/usr/sbin:/sbin", "LANG": "C.UTF-8"})
        if result.returncode:
            raise RuntimeError("command failed during " + self.stage)
        return result.stdout

    def own(self, path, mode):
        user = pwd.getpwnam("fort")
        os.chown(path, user.pw_uid, user.pw_gid)
        path.chmod(mode)

    def download(self, url, sha, path):
        validate_url(url)
        if not re.fullmatch("[a-f0-9]{64}", sha):
            raise RuntimeError("an exact SHA-256 is required")
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        digest, total = hashlib.sha256(), 0
        try:
            with open_url(url) as response, path.open("wb") as out:
                path.chmod(0o600)
                while chunk := response.read(1024 * 1024):
                    total += len(chunk)
                    if total > MAX_BINARY:
                        raise RuntimeError("binary too large")
                    digest.update(chunk)
                    out.write(chunk)
            if not total or digest.hexdigest() != sha:
                raise RuntimeError("binary SHA-256 mismatch")
            path.chmod(0o755)
        except Exception:
            path.unlink(missing_ok=True)
            raise

    def secret(self, cfg):
        if cfg["cloud"] == "aws":
            import boto3
            from botocore.config import Config
            client = boto3.client("secretsmanager", region_name=cfg["region"], config=Config(
                connect_timeout=5, read_timeout=30, retries={"total_max_attempts": 3}))
            result = client.get_secret_value(SecretId=cfg["secret_id"],
                                            VersionId=cfg["secret_version"])
            return json.loads(result["SecretString"])
        if cfg["cloud"] != "gcp":
            raise RuntimeError("unknown cloud")
        token_request = urllib.request.Request(
            "http://169.254.169.254/computeMetadata/v1/instance/service-accounts/default/token",
            headers={"Metadata-Flavor": "Google"})
        with open_url(token_request) as response:
            token = json.loads(response.read(65537))["access_token"]
        request = urllib.request.Request(
            "https://secretmanager.googleapis.com/v1/" + cfg["secret_id"] +
            "/versions/" + cfg["secret_version"] + ":access",
            headers={"Authorization": "Bearer " + token})
        with open_url(request) as response:
            payload = json.loads(response.read(131073))["payload"]["data"]
        return json.loads(base64.b64decode(payload, validate=True))

    def console(self, ip, hostname, cert):
        # Chain is operator supplied; validate the same hostname the browser will use.
        context = ssl.create_default_context(cafile=str(cert))
        context.verify_flags |= ssl.VERIFY_X509_PARTIAL_CHAIN
        with socket.create_connection((ip, 7451), timeout=10) as raw:
            with context.wrap_socket(raw, server_hostname=hostname) as conn:
                conn.sendall(("GET / HTTP/1.1\r\nHost: " + hostname +
                              ":7451\r\nConnection: close\r\n\r\n").encode())
                data = bytearray()
                while len(data) <= 1024 * 1024:
                    chunk = conn.recv(65536)
                    if not chunk:
                        break
                    data.extend(chunk)
        if (not data.startswith(b"HTTP/1.1 200") or b"text/html" not in data.lower()
                or b"/assets/" not in data or b"console not built" in data.lower()):
            raise RuntimeError("console assets are unavailable")


def atomic(path, text, mode=0o600, owner=None):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temp = tempfile.mkstemp(dir=path.parent)
    try:
        with os.fdopen(fd, "w") as out:
            if owner is not None:
                os.fchown(out.fileno(), *owner)
            os.fchmod(out.fileno(), mode)
            out.write(text)
            out.flush()
            os.fsync(out.fileno())
        os.replace(temp, path)
    finally:
        Path(temp).unlink(missing_ok=True)


def prepare_hostname(host):
    path = host.root / "etc/hostname"
    try:
        if path.read_text().strip():
            return
    except FileNotFoundError:
        pass
    # Some cloud images supply only a kernel hostname; Fort also reads this file.
    hostname = host.run(["hostname"]).removesuffix("\n")
    label = r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?"
    if not 1 <= len(hostname) <= 253 or not re.fullmatch(label + r"(?:\." + label + r")*", hostname):
        raise RuntimeError("kernel hostname is missing or invalid")
    atomic(path, hostname + "\n", 0o644, owner=(0, 0))


def private_ip(host):
    route = json.loads(host.run(["ip", "-j", "route", "show", "default"]))[0]
    addresses = json.loads(host.run(["ip", "-j", "address", "show", "dev", route["dev"]]))
    return next(a["local"] for i in addresses for a in i["addr_info"]
                if a["family"] == "inet" and a.get("scope") == "global")


def write_secrets(host, payload, hostname):
    required = {"tls_certificate", "tls_private_key"}
    optional = {"console_oidc_client_secret", "step_up_client_secret"}
    if not required <= payload.keys() or payload.keys() - required - optional:
        raise RuntimeError("invalid bootstrap secret keys")
    if any(not isinstance(v, str) or not v or len(v.encode()) > 65536
           for v in payload.values()):
        raise RuntimeError("invalid bootstrap secret value")
    host.etc.mkdir(parents=True, exist_ok=True, mode=0o700)
    # fort must traverse its private key directory; other users must not.
    host.own(host.etc, 0o700)
    files = {"tls_certificate": ("tls.pem", 0o644), "tls_private_key": ("tls.key", 0o600),
             "console_oidc_client_secret": ("console.secret", 0o600),
             "step_up_client_secret": ("device.secret", 0o600)}
    for key, (name, mode) in files.items():
        path = host.etc / name
        if key in payload:
            atomic(path, payload[key], mode)
            host.own(path, mode)
        elif path.exists():
            raise RuntimeError("secret removal requires explicit maintenance")
    cert, key = str(host.etc / "tls.pem"), str(host.etc / "tls.key")
    # x509 -checkhost returns success on a mismatch in Ubuntu's OpenSSL 3.0.
    # The verify command makes hostname and server-certificate failures nonzero.
    host.run(["openssl", "verify", "-partial_chain", "-trusted", cert,
              "-purpose", "sslserver", "-verify_hostname", hostname, cert])
    host.run(["openssl", "x509", "-in", cert, "-noout", "-checkend", "86400"])
    pub_cert = host.run(["openssl", "x509", "-in", cert, "-pubkey", "-noout"])
    pub_key = host.run(["openssl", "pkey", "-in", key, "-pubout"])
    if pub_cert.strip() != pub_key.strip():
        raise RuntimeError("TLS key does not match certificate")


def bind_admin(host, binary, fort, stamp):
    if host.path("admin-bound").exists():
        if host.path("admin-bound").read_text() != stamp:
            raise RuntimeError("initial admin configuration changed")
        return
    flag, qualified, kind, value = admin_identity(fort)
    cli = [str(binary), "--context", "local", "--output", "json"]

    def confirmed():
        bindings = json.loads(host.run(cli + ["role", "bindings"])).get("bindings", [])
        if kind == "group":
            return has_binding(bindings, kind, value)
        principals = json.loads(host.run(cli + ["identity", "principals"])).get("principals", [])
        resolved = principal_id(principals, fort["oidc_issuer"], value)
        return resolved is not None and has_binding(bindings, "userId", resolved)

    if not confirmed():
        host.run(cli + ["role", "bind", "admin", flag, qualified, "--scope", "global"])
    if not confirmed():
        raise RuntimeError("initial admin binding was not confirmed")
    atomic(host.path("admin-bound"), stamp)


def install(cfg, host):
    host.work.mkdir(parents=True, exist_ok=True, mode=0o700)
    host.work.chmod(0o700)
    stamp = hashlib.sha256(json.dumps(cfg, sort_keys=True).encode()).hexdigest()
    for name in ("done", "admin-bound", "configuration"):
        p = host.path(name)
        if p.exists() and p.read_text() != stamp:
            raise RuntimeError("configuration changed; use documented maintenance procedure")
    if host.path("done").exists():
        return
    atomic(host.path("configuration"), stamp)
    fort = cfg["fort"]
    admin_identity(fort)
    host.stage = "binary verification"
    binaries = host.path("bin")
    binaries.mkdir(exist_ok=True, mode=0o700)
    for name in ("fort", "fortd"):
        host.download(fort[name + "_url"], fort[name + "_sha256"], binaries / name)
    binary = binaries / "fort"
    args = [str(binary), "up", "--api-addr", "127.0.0.1", "--yes",
            "--oidc-issuer", fort["oidc_issuer"], "--oidc-client-id", fort["oidc_client_id"],
            "--oidc-groups-claim", fort["oidc_groups_claim"]]
    if fort["oidc_audience"]:
        args += ["--oidc-audience", fort["oidc_audience"]]
    host.stage = "host preparation"
    prepare_hostname(host)
    host.stage = "base installation"
    if not host.path("base-installed").exists():
        host.run(args + ["--no-console"])
        atomic(host.path("base-installed"), stamp)
    host.stage = "TLS and client secrets"
    payload = host.secret(cfg)
    write_secrets(host, payload, fort["hostname"])
    ip = private_ip(host)
    url = "https://" + fort["hostname"] + ":7451"
    args += ["--console", "--console-listen", ip + ":7451", "--console-public-url", url,
             "--console-tls-cert", str(host.etc / "tls.pem"),
             "--console-tls-key", str(host.etc / "tls.key"),
             "--console-environment-name", fort["environment_name"]]
    for key, flag in (("console_oidc_client_id", "--console-oidc-client-id"),
                      ("step_up_client_id", "--step-up-client-id")):
        if fort[key]:
            args += [flag, fort[key]]
    for key, name, flag in (("console_oidc_client_secret", "console.secret",
                            "--console-oidc-client-secret-file"),
                           ("step_up_client_secret", "device.secret",
                            "--step-up-client-secret-file")):
        if key in payload:
            args += [flag, str(host.etc / name)]
    host.stage = "console installation"
    host.run(args)
    host.stage = "initial administrator binding"
    bind_admin(host, binary, fort, stamp)
    host.stage = "readiness verification"
    host.run([str(binary), "doctor"])
    for service in ("fortd", "openshell-gateway"):
        host.run(["systemctl", "is-active", "--quiet", service])
    host.console(ip, fort["hostname"], host.etc / "tls.pem")
    atomic(host.path("done"), stamp)
    print("Fort bootstrap ready: " + url)


def main(config_path=Path("/var/lib/fort-onboarding/config.json")):
    host = Host()
    try:
        install(json.loads(config_path.read_text()), host)
        return 0
    except Exception:
        print("Fort bootstrap failed during " + host.stage +
              "; no ready marker was written. See the customer deployment README.", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
