variable "config" {
  description = "Non-secret cloud and Fort settings; secret references only."
  type        = any
}

variable "docker_version" {
  description = "Exact Docker apt version qualified by the operator."
  type        = string
}

variable "extra_files" {
  description = "Extra root-only helper files (name to base64 content) written next to the bootstrap; none for AWS and GCP."
  type        = map(string)
  default     = {}
  validation {
    condition     = alltrue([for n, c in var.extra_files : can(regex("^[a-z][a-z0-9_]*[.]py$", n)) && can(regex("^[A-Za-z0-9+/=]+$", c))])
    error_message = "Extra files are Python helpers with simple names and base64 content."
  }
}

variable "extra_packages" {
  description = "Extra apt packages for the first boot; none for AWS and GCP."
  type        = list(string)
  default     = []
  validation {
    condition     = alltrue([for p in var.extra_packages : can(regex("^[a-z0-9][a-z0-9+.-]*$", p))])
    error_message = "Package names are plain apt names."
  }
}

variable "preamble" {
  description = "Shell lines run before the first package install; empty for AWS and GCP."
  type        = string
  default     = ""
  validation {
    condition     = length(var.preamble) <= 1000 && !strcontains(var.preamble, "$${")
    error_message = "The preamble is short and holds no template syntax."
  }
}

variable "entrypoint" {
  description = "The Python file the boot script runs from /var/lib/fort-onboarding."
  type        = string
  default     = "bootstrap.py"
  validation {
    condition     = can(regex("^[a-z][a-z0-9_]*[.]py$", var.entrypoint))
    error_message = "The entry point is a Python file with a simple name."
  }
}
