variable "config" {
  description = "Non-secret cloud and Fort settings; secret references only."
  type        = any
}

variable "docker_version" {
  description = "Exact Docker apt version qualified by the operator."
  type        = string
}
