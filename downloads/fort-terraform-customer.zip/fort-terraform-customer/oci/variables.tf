variable "tenancy_ocid" {
  description = "The tenancy (root compartment) OCID. The dynamic group and its policy live here, so the deployment compartment cannot stand in for it."
  type        = string
  validation {
    condition     = can(regex("^ocid1[.]tenancy[.]oc[0-9]+[.][a-z0-9-]*[.][a-z0-9]+$", var.tenancy_ocid))
    error_message = "Supply the tenancy OCID (ocid1.tenancy...)."
  }
}

variable "compartment_id" {
  description = "Existing compartment that holds the Fort VM and, unless you supply a subnet, its dedicated network."
  type        = string
  validation {
    condition     = can(regex("^ocid1[.](compartment|tenancy)[.]oc[0-9]+[.][a-z0-9-]*[.][a-z0-9]+$", var.compartment_id))
    error_message = "Supply a compartment OCID (ocid1.compartment...)."
  }
}

variable "region" {
  description = "Region identifier of the deployment, for example eu-frankfurt-1."
  type        = string
  validation {
    condition     = can(regex("^[a-z]{2}-[a-z0-9]+(-[a-z0-9]+)*-[0-9]+$", var.region))
    error_message = "Use an OCI region identifier such as us-ashburn-1."
  }
}

variable "home_region" {
  description = "The tenancy's home region: IAM resources can only be created there. No default, so a wrong guess cannot be applied silently."
  type        = string
  validation {
    condition     = can(regex("^[a-z]{2}-[a-z0-9]+(-[a-z0-9]+)*-[0-9]+$", var.home_region))
    error_message = "Use the home region identifier of the tenancy, for example us-ashburn-1."
  }
}

variable "availability_domain" {
  description = "Availability domain name within region, as shown by `oci iam availability-domain list`."
  type        = string
  validation {
    condition     = can(regex("^[A-Za-z0-9:_.-]{1,100}$", var.availability_domain))
    error_message = "Use the full availability domain name."
  }
}

variable "image_id" {
  description = "Pinned Canonical Ubuntu 24.04 x86_64 image OCID in this region; never a name or `latest`."
  type        = string
  validation {
    condition     = can(regex("^ocid1[.]image[.]oc[0-9]+[.][a-z0-9-]*[.][a-z0-9]+$", var.image_id))
    error_message = "Supply an image OCID (ocid1.image...)."
  }
}

variable "shape" {
  description = "x86_64 flexible shape; the default with 2 OCPUs and 16 GiB is the 4 vCPU / 16 GiB starting size."
  type        = string
  default     = "VM.Standard.E5.Flex"
  validation {
    condition     = can(regex("^VM[.]Standard[.](E|X)[0-9]+[.]Flex$", var.shape))
    error_message = "Use an x86_64 flexible VM shape such as VM.Standard.E5.Flex."
  }
}

variable "ocpus" {
  description = "OCPUs of the flexible shape (one OCPU is two vCPUs)."
  type        = number
  default     = 2
  validation {
    condition     = var.ocpus >= 2 && floor(var.ocpus) == var.ocpus
    error_message = "Use a whole number of at least 2 OCPUs."
  }
}

variable "memory_in_gbs" {
  description = "Memory of the flexible shape in GiB."
  type        = number
  default     = 16
  validation {
    condition     = var.memory_in_gbs >= 16 && floor(var.memory_in_gbs) == var.memory_in_gbs
    error_message = "Use a whole number of at least 16 GiB."
  }
}

variable "boot_volume_size_in_gbs" {
  description = "Retained root volume; back up Fort before any intentional replacement."
  type        = number
  default     = 120
  validation {
    condition     = var.boot_volume_size_in_gbs >= 120 && floor(var.boot_volume_size_in_gbs) == var.boot_volume_size_in_gbs
    error_message = "Use an integer boot volume size of at least 120 GiB."
  }
}

variable "shielded_instance" {
  description = "Turn on secure boot, the virtual TPM and measured boot. Needs an AMD shape and an image that supports them; confirm in your tenancy first."
  type        = bool
  default     = false
}

variable "subnet_id" {
  description = "Optional existing public subnet. Null creates a dedicated VCN, gateway, route table, security list and subnet."
  type        = string
  default     = null
  validation {
    condition     = var.subnet_id == null || can(regex("^ocid1[.]subnet[.]oc[0-9]+[.][a-z0-9-]*[.][a-z0-9]+$", coalesce(var.subnet_id, "x")))
    error_message = "Supply a subnet OCID (ocid1.subnet...) or leave it null."
  }
}

variable "vcn_cidr" {
  description = "IPv4 range of the new dedicated VCN; avoid Docker's ranges. Ignored with subnet_id."
  type        = string
  default     = "10.80.0.0/16"
  validation {
    condition     = can(cidrnetmask(var.vcn_cidr))
    error_message = "Supply a valid IPv4 CIDR."
  }
}

variable "subnet_cidr" {
  description = "IPv4 range of the new dedicated subnet, inside vcn_cidr. Ignored with subnet_id."
  type        = string
  default     = "10.80.0.0/24"
  validation {
    condition     = can(cidrnetmask(var.subnet_cidr))
    error_message = "Supply a valid IPv4 subnet CIDR."
  }
}

variable "ssh_authorized_keys" {
  description = "SSH public keys set at launch; required when ssh_cidrs is set; at most 4 keys of 768 characters, which holds an RSA-4096 key, so the boot script fits the instance metadata limit."
  type        = list(string)
  default     = []
  validation {
    condition     = length(var.ssh_authorized_keys) <= 4 && alltrue([for k in var.ssh_authorized_keys : length(k) <= 768 && can(regex("^(ssh-(rsa|ed25519)|ecdsa-sha2-nistp[0-9]+) [A-Za-z0-9+/=]+( [^\\n]*)?$", k))])
    error_message = "Supply at most 4 single-line SSH public keys of at most 768 characters each."
  }
}

variable "bootstrap_secret_id" {
  description = "OCID of the existing Vault secret holding the documented JSON (not its value)."
  type        = string
  validation {
    condition     = can(regex("^ocid1[.]vaultsecret[.]oc[0-9]+[.][a-z0-9-]*[.][a-z0-9]+$", var.bootstrap_secret_id))
    error_message = "Supply the secret OCID (ocid1.vaultsecret...)."
  }
}

variable "bootstrap_secret_version" {
  description = "Immutable numeric version of that secret; never latest."
  type        = string
  validation {
    condition     = can(regex("^[1-9][0-9]{0,8}$", var.bootstrap_secret_version))
    error_message = "Supply an exact numbered secret version."
  }
}

variable "dns_zone_id" {
  description = "Optional existing public DNS zone OCID (or name) for an A record; null means manage DNS yourself."
  type        = string
  default     = null
}
