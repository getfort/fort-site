variable "fort" {
  description = "Shared Fort settings. Secrets are fetched by reference at boot, never supplied here."
  type = object({
    hostname               = string
    environment_name       = optional(string, "Production")
    fort_url               = string
    fort_sha256            = string
    fortd_url              = string
    fortd_sha256           = string
    oidc_issuer            = string
    oidc_client_id         = string
    oidc_audience          = optional(string, "")
    oidc_groups_claim      = optional(string, "groups")
    console_oidc_client_id = optional(string, "")
    step_up_client_id      = optional(string, "")
    admin_group            = optional(string, "")
    admin_subject          = optional(string, "")
  })
  validation {
    condition     = can(regex("^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$", var.fort.hostname)) && length(var.fort.hostname) <= 253 && !strcontains(var.fort.hostname, "..")
    error_message = "hostname must be a lowercase DNS hostname without scheme, port or path."
  }
  validation {
    condition     = alltrue([for u in [var.fort.fort_url, var.fort.fortd_url, var.fort.oidc_issuer] : can(regex("^https://[^/?#@[:space:]]+(/[^?#[:space:]]*)?$", u))])
    error_message = "Artifact and issuer URLs must be direct HTTPS URLs without credentials, query or fragment."
  }
  validation {
    condition     = alltrue([for h in [var.fort.fort_sha256, var.fort.fortd_sha256] : can(regex("^[a-f0-9]{64}$", h))])
    error_message = "Both binaries require lowercase SHA-256 pins, 64 hexadecimal characters each."
  }
  validation {
    condition     = (var.fort.admin_group != "") != (var.fort.admin_subject != "")
    error_message = "Set exactly one admin_group or immutable admin_subject (OIDC sub, not email)."
  }
  // Bounds so the largest accepted input still fits the instance metadata (see main.tf).
  validation {
    condition = alltrue([for u in [var.fort.fort_url, var.fort.fortd_url, var.fort.oidc_issuer] : length(u) <= 512]) && alltrue([
      for v in [var.fort.environment_name, var.fort.oidc_client_id, var.fort.oidc_audience, var.fort.oidc_groups_claim, var.fort.console_oidc_client_id, var.fort.step_up_client_id, var.fort.admin_group, var.fort.admin_subject] : length(v) <= 256
    ])
    error_message = "URLs are at most 512 characters; client ids, audience, claim, admin group or subject and environment name at most 256."
  }
  validation {
    condition     = alltrue([for v in [var.fort.environment_name, var.fort.oidc_client_id, var.fort.oidc_groups_claim] : trimspace(v) != ""]) && length(var.fort.environment_name) <= 64
    error_message = "Environment, OIDC client and groups claim must be nonblank; environment is at most 64 characters."
  }
}

variable "name" {
  description = "Resource name prefix (3–24 lowercase letters, digits or hyphens)."
  type        = string
  default     = "fort"
  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{1,22}[a-z0-9]$", var.name))
    error_message = "name must be 3–24 lowercase letters/digits/hyphens, beginning with a letter."
  }
}

variable "console_cidrs" {
  description = "IPv4 source networks allowed to reach the HTTPS console on 7451."
  type        = set(string)
  validation {
    condition     = length(var.console_cidrs) > 0 && alltrue([for c in var.console_cidrs : try(cidrnetmask(c) != "0.0.0.0", false)])
    error_message = "Supply explicit IPv4 console CIDRs; an empty list or 0.0.0.0/0 is refused."
  }
}

variable "ssh_cidrs" {
  description = "Optional IPv4 SSH source networks; empty means no SSH ingress."
  type        = set(string)
  default     = []
  validation {
    condition     = alltrue([for c in var.ssh_cidrs : try(cidrnetmask(c) != "0.0.0.0", false)])
    error_message = "SSH CIDRs must be explicit IPv4 networks, never 0.0.0.0/0."
  }
}

variable "docker_version" {
  description = "Exact Docker apt version; this is the version qualified in the M0 GCP spike and used unchanged on every cloud."
  type        = string
  default     = "5:29.9.2-1~ubuntu.24.04~noble"
  validation {
    condition     = can(regex("^[0-9]+:[0-9.]+-[0-9]+~ubuntu[.]24[.]04~noble$", var.docker_version))
    error_message = "Use an exact Docker Ubuntu 24.04 apt package version."
  }
}
