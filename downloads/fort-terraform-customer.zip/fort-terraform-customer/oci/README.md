# Fort customer installation on Oracle Cloud (OCI)

Start with the [customer deployment guide](../README.md), which covers binary delivery,
TLS/secret preparation, company sign-in, initial administrator, readiness and maintenance.
Copy `terraform.tfvars.example` to `terraform.tfvars` and replace every example value.

```sh
terraform init
terraform plan -out=install.tfplan
terraform apply install.tfplan
terraform output console_url
```

`terraform apply` creates infrastructure; it does not wait for the guest installation.
The console is HTTPS on 7451; its API on 7443 stays loopback-only. SSH defaults off.

## What it creates

- A dedicated network (VCN, internet gateway, route table, a security list with **no**
  ingress, and a public subnet), unless you give `subnet_id`. An existing subnet is
  accepted only if none of its security lists admits TCP 22, TCP 7451 or all protocols,
  because OCI lets a security list or a network security group open a port.
- A network security group, the only way in: TCP 7451 from each `console_cidrs` entry,
  and TCP 22 from each `ssh_cidrs` entry when you set them. `0.0.0.0/0` is refused.
- The VM (default `VM.Standard.E5.Flex`, 2 OCPUs and 16 GiB, a 120 GiB root volume that is
  kept if the VM is destroyed on purpose), a reserved public IP and an optional DNS A record.
- In the tenancy, on the home region: a **dynamic group** matching this one VM and a **policy**
  that lets it read the one bootstrap secret (`read secret-bundles ... where
  target.secret.id = '<your secret>'`) and nothing else. They are created in the tenancy's
  default identity domain.

## Before you apply

- Credentials able to create the above, including **manage dynamic-groups** and **manage
  policies** in the tenancy (these two resources are written in `home_region`).
- A Vault secret holding the documented JSON (see the guide) and its **version number**.
  The VM reads that exact version, never the latest.
- A pinned Canonical Ubuntu 24.04 x86_64 image in `region`:
  `oci compute image list --compartment-id <id> --operating-system "Canonical Ubuntu"
  --operating-system-version 24.04 --shape VM.Standard.E5.Flex`.

## First boot

The VM signs in to OCI as itself (instance principal), reads the secret and installs Fort.
The dynamic group and policy exist only after the VM does, and take a short while to apply,
so the first secret read can be refused for a few minutes. It retries for up to ten
minutes, then stops and names the dynamic group and policy to check. Read the progress in
the instance's **console history** (Compute > the instance > Console history, or
`oci compute console-history capture`) and look for `Fort bootstrap ready: https://...`.
Oracle's Ubuntu images also block inbound ports in the VM itself; the boot adds one saved
firewall rule for 7451 and touches nothing else.

## Retry a failed first boot

On OCI, retry as root with the OCI entry point, not the command in the shared guide
(`bootstrap.py` alone does not know how to read an OCI Vault secret):

```sh
sudo python3 /var/lib/fort-onboarding/oci_bootstrap.py
```

If the stop names the dynamic group and policy, check that both exist in the tenancy, that
the group matches this instance's OCID and that the policy names your secret, then retry.

## Notes

Provider versions and checksums are committed. Use this folder from a checkout together
with `../shared`; do not copy it alone. A new deployment needs its own state and name. The
VM blocks destruction and replacement; read the guide before changing or deleting it.
The boot script travels compressed in the instance metadata and the plan refuses inputs
that would not fit OCI's 32,000-byte limit (at most 4 SSH keys of 768 characters, bounded
settings). Secure boot is off unless you set `shielded_instance` after confirming your
shape and image support it.
