terraform {
  required_version = ">= 1.9, < 2.0"
  required_providers {
    oci = {
      source  = "oracle/oci"
      version = "= 9.13.0"
    }
  }
}
// The deployment region. Credentials come from the operator's usual OCI configuration or
// environment; nothing is read from a file in this module.
provider "oci" {
  region = var.region
}
// Identity resources (the dynamic group and the policy) live in the tenancy's home region.
provider "oci" {
  alias  = "home"
  region = var.home_region
}
