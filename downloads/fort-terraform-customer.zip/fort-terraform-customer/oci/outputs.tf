output "console_url" {
  value = module.bootstrap.console_url
}
output "oidc_callback_url" {
  value = module.bootstrap.oidc_callback_url
}
output "public_ip" {
  value = oci_core_public_ip.console.ip_address
}
output "instance_id" {
  value = oci_core_instance.fort.id
}
output "network_id" {
  value = local.vcn_id
}
output "dynamic_group_name" {
  value = oci_identity_dynamic_group.fort.name
}
output "readiness" {
  value = "Infrastructure creation is not guest readiness. The first boot waits for the Vault policy to apply (up to ten minutes). Check the instance's console history for 'Fort bootstrap ready', then open console_url and sign in."
}
