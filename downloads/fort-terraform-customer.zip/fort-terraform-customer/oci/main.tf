locals {
  dedicated          = var.subnet_id == null
  dynamic_group_name = "${var.name}-instance"
  policy_name        = "${var.name}-bootstrap-secret"
  vcn_id             = local.dedicated ? oci_core_vcn.fort[0].id : data.oci_core_subnet.existing[0].vcn_id
  subnet_id          = local.dedicated ? oci_core_subnet.fort[0].id : var.subnet_id

  // The public address is attached just after the instance starts, and the boot script runs
  // once, so it waits (up to ten minutes) for the way out to the package servers to exist.
  wait_for_network = "\nfor _ in $(seq 1 120); do curl --fail --silent --max-time 5 --proto '=https' -o /dev/null https://download.docker.com/linux/ubuntu/gpg && break; sleep 5; done"

  helpers = {
    "oci_secret.py"    = filebase64("${path.module}/../shared/oci_secret.py")
    "oci_bootstrap.py" = filebase64("${path.module}/../shared/oci_bootstrap.py")
  }

  // OCI limits the combined instance metadata to 32,000 bytes; the script is sent compressed.
  user_data = base64gzip(module.bootstrap.script)
  metadata = merge(
    { user_data = local.user_data },
    length(var.ssh_authorized_keys) == 0 ? {} : { ssh_authorized_keys = join("\n", var.ssh_authorized_keys) },
  )
  metadata_bytes = sum([for k, v in local.metadata : length(k) + length(v)])

  // An existing subnet is accepted only if none of its security lists lets traffic in to the
  // ports Fort must keep closed to everyone but the CIDRs below, which only the network
  // security group may open. OCI admits what either a list or a group allows. A rule that
  // cannot be read as safe counts as open.
  // The lookup can only see lists in the subnet's compartment (a list moved to another
  // compartment stays attached), so a list that is not found exactly once is refused too.
  unreadable = local.dedicated ? [] : [
    for id, found in data.oci_core_security_lists.existing :
    "security list ${id} could not be inspected (it must be in the subnet's compartment)"
    if length(found.security_lists) != 1
  ]
  exposed = local.dedicated ? [] : concat(local.unreadable, flatten([
    for id, found in data.oci_core_security_lists.existing : [
      for sl in found.security_lists : [
        for r in sl.ingress_security_rules :
        "${sl.display_name} (protocol ${r.protocol} from ${r.source})"
        if r.protocol == "all" || (r.protocol == "6" && try(
          // No destination range, or one the provider reports as 0 to 0 (a rule that limits only
          // the source port), allows every destination port. Conditionals, not `||`, guard the
          // index: Terraform before 1.12 evaluates both sides of `||`.
          length(r.tcp_options) == 0 ? true : (
            r.tcp_options[0].min < 1 || r.tcp_options[0].max < 1 ||
            anytrue([for p in [22, 7451] : r.tcp_options[0].min <= p && p <= r.tcp_options[0].max])
          ),
        true))
      ]
    ]
  ]))
}

module "bootstrap" {
  source         = "../shared"
  docker_version = var.docker_version
  extra_files    = local.helpers
  extra_packages = ["iptables-persistent"]
  entrypoint     = "oci_bootstrap.py"
  preamble       = local.wait_for_network
  config = {
    cloud             = "oci"
    region            = var.region
    secret_id         = var.bootstrap_secret_id
    secret_version    = var.bootstrap_secret_version
    oci_dynamic_group = local.dynamic_group_name
    oci_policy        = local.policy_name
    fort              = var.fort
  }
}

// ---- Network: dedicated, unless an existing public subnet is supplied.

resource "oci_core_vcn" "fort" {
  count          = local.dedicated ? 1 : 0
  compartment_id = var.compartment_id
  display_name   = "${var.name}-net"
  cidr_blocks    = [var.vcn_cidr]
}

resource "oci_core_internet_gateway" "fort" {
  count          = local.dedicated ? 1 : 0
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.fort[0].id
  display_name   = "${var.name}-gateway"
  enabled        = true
}

resource "oci_core_route_table" "fort" {
  count          = local.dedicated ? 1 : 0
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.fort[0].id
  display_name   = "${var.name}-routes"
  route_rules {
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_internet_gateway.fort[0].id
  }
}

// No ingress at all: the VCN's default list would admit SSH from anywhere.
resource "oci_core_security_list" "fort" {
  count          = local.dedicated ? 1 : 0
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.fort[0].id
  display_name   = "${var.name}-no-ingress"
  egress_security_rules {
    destination      = "0.0.0.0/0"
    destination_type = "CIDR_BLOCK"
    protocol         = "all"
  }
}

resource "oci_core_subnet" "fort" {
  count                      = local.dedicated ? 1 : 0
  compartment_id             = var.compartment_id
  vcn_id                     = oci_core_vcn.fort[0].id
  display_name               = "${var.name}-subnet"
  cidr_block                 = var.subnet_cidr
  route_table_id             = oci_core_route_table.fort[0].id
  security_list_ids          = [oci_core_security_list.fort[0].id]
  prohibit_public_ip_on_vnic = false
}

data "oci_core_subnet" "existing" {
  count     = local.dedicated ? 0 : 1
  subnet_id = var.subnet_id
}

data "oci_core_security_lists" "existing" {
  for_each       = local.dedicated ? toset([]) : toset(data.oci_core_subnet.existing[0].security_list_ids)
  compartment_id = data.oci_core_subnet.existing[0].compartment_id
  vcn_id         = data.oci_core_subnet.existing[0].vcn_id
  filter {
    name   = "id"
    values = [each.value]
  }
}

// ---- The only way in: a network security group with explicit CIDRs.

resource "oci_core_network_security_group" "fort" {
  compartment_id = var.compartment_id
  vcn_id         = local.vcn_id
  display_name   = "${var.name}-console"
}

resource "oci_core_network_security_group_security_rule" "console" {
  for_each                  = var.console_cidrs
  network_security_group_id = oci_core_network_security_group.fort.id
  direction                 = "INGRESS"
  protocol                  = "6"
  source                    = each.value
  source_type               = "CIDR_BLOCK"
  description               = "Fort console"
  tcp_options {
    destination_port_range {
      min = 7451
      max = 7451
    }
  }
}

resource "oci_core_network_security_group_security_rule" "ssh" {
  for_each                  = var.ssh_cidrs
  network_security_group_id = oci_core_network_security_group.fort.id
  direction                 = "INGRESS"
  protocol                  = "6"
  source                    = each.value
  source_type               = "CIDR_BLOCK"
  description               = "SSH"
  tcp_options {
    destination_port_range {
      min = 22
      max = 22
    }
  }
}

resource "oci_core_network_security_group_security_rule" "egress" {
  network_security_group_id = oci_core_network_security_group.fort.id
  direction                 = "EGRESS"
  protocol                  = "all"
  destination               = "0.0.0.0/0"
  destination_type          = "CIDR_BLOCK"
  description               = "Artifacts, packages, the identity provider and the Vault"
}

// ---- The VM.

resource "oci_core_instance" "fort" {
  compartment_id      = var.compartment_id
  availability_domain = var.availability_domain
  display_name        = var.name
  shape               = var.shape
  // Keep the root volume when the instance is destroyed on purpose.
  preserve_boot_volume = true
  shape_config {
    ocpus         = var.ocpus
    memory_in_gbs = var.memory_in_gbs
  }
  source_details {
    source_type             = "image"
    source_id               = var.image_id
    boot_volume_size_in_gbs = var.boot_volume_size_in_gbs
  }
  create_vnic_details {
    subnet_id              = local.subnet_id
    assign_public_ip       = false
    nsg_ids                = [oci_core_network_security_group.fort.id]
    skip_source_dest_check = false
  }
  instance_options {
    are_legacy_imds_endpoints_disabled = true
  }
  dynamic "platform_config" {
    for_each = var.shielded_instance ? [1] : []
    content {
      type                               = "AMD_VM"
      is_secure_boot_enabled             = true
      is_trusted_platform_module_enabled = true
      is_measured_boot_enabled           = true
    }
  }
  metadata = local.metadata
  lifecycle {
    prevent_destroy = true
    precondition {
      condition     = local.metadata_bytes <= 28000
      error_message = "The instance metadata would exceed OCI's 32,000-byte limit (the boot script is sent compressed). Shorten the fort settings or the SSH keys."
    }
    precondition {
      condition     = length(var.ssh_cidrs) == 0 || length(var.ssh_authorized_keys) > 0
      error_message = "ssh_cidrs opens SSH, so ssh_authorized_keys must hold at least one public key."
    }
    precondition {
      condition     = length(local.exposed) == 0
      error_message = "The existing subnet's security lists already admit traffic to Fort's ports from anywhere they name: ${join("; ", local.exposed)}. OCI admits what either a security list or a network security group allows, so use the dedicated network (leave subnet_id null) or remove those rules."
    }
    precondition {
      condition     = local.dedicated ? true : !data.oci_core_subnet.existing[0].prohibit_public_ip_on_vnic
      error_message = "The existing subnet prohibits public IP addresses, but the console needs a public one. Use a public subnet or the dedicated network."
    }
  }
}

// ---- The address: reserved, so it survives a rebuild and DNS can point at it.

data "oci_core_vnic_attachments" "fort" {
  compartment_id = var.compartment_id
  instance_id    = oci_core_instance.fort.id
}

data "oci_core_private_ips" "fort" {
  vnic_id = data.oci_core_vnic_attachments.fort.vnic_attachments[0].vnic_id
}

resource "oci_core_public_ip" "console" {
  compartment_id = var.compartment_id
  lifetime       = "RESERVED"
  display_name   = "${var.name}-ip"
  private_ip_id  = [for p in data.oci_core_private_ips.fort.private_ips : p.id if p.is_primary][0]
}

resource "oci_dns_rrset" "console" {
  count           = var.dns_zone_id == null ? 0 : 1
  zone_name_or_id = var.dns_zone_id
  domain          = var.fort.hostname
  rtype           = "A"
  items {
    domain = var.fort.hostname
    rtype  = "A"
    rdata  = oci_core_public_ip.console.ip_address
    ttl    = 300
  }
}

// ---- Who may read the bootstrap secret: this instance, one secret, nothing else.

resource "oci_identity_dynamic_group" "fort" {
  provider       = oci.home
  compartment_id = var.tenancy_ocid
  name           = local.dynamic_group_name
  description    = "The Fort VM, so it can read its own bootstrap secret"
  matching_rule  = "instance.id = '${oci_core_instance.fort.id}'"
}

resource "oci_identity_policy" "fort" {
  provider       = oci.home
  compartment_id = var.tenancy_ocid
  name           = local.policy_name
  description    = "Lets the Fort VM read one bootstrap secret"
  statements = [
    "Allow dynamic-group ${oci_identity_dynamic_group.fort.name} to read secret-bundles in compartment id ${var.compartment_id} where target.secret.id = '${var.bootstrap_secret_id}'",
  ]
}
