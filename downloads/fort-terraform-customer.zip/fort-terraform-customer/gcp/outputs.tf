output "console_url" {
  value = module.bootstrap.console_url
}
output "oidc_callback_url" {
  value = module.bootstrap.oidc_callback_url
}
output "public_ip" {
  value = google_compute_address.console.address
}
output "instance_name" {
  value = google_compute_instance.fort.name
}
output "service_account_email" {
  value = google_service_account.vm.email
}
output "network_name" {
  value = google_compute_network.fort.name
}
output "readiness" {
  value = "Infrastructure creation is not guest readiness. Check serial output for 'Fort bootstrap ready', then open console_url and sign in."
}
