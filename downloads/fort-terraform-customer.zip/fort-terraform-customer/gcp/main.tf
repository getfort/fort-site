resource "google_project_service" "required" {
  for_each           = toset(["compute.googleapis.com", "iam.googleapis.com", "secretmanager.googleapis.com"])
  project            = var.project_id
  service            = each.value
  disable_on_destroy = false
}
resource "google_compute_network" "fort" {
  project                 = var.project_id
  name                    = "${var.name}-net"
  auto_create_subnetworks = false
  depends_on              = [google_project_service.required]
}
resource "google_compute_subnetwork" "fort" {
  project                  = var.project_id
  name                     = "${var.name}-subnet"
  region                   = var.region
  network                  = google_compute_network.fort.id
  ip_cidr_range            = var.subnet_cidr
  private_ip_google_access = true
}
resource "google_service_account" "vm" {
  project      = var.project_id
  account_id   = "${var.name}-vm"
  display_name = "Fort bootstrap secret reader"
  depends_on   = [google_project_service.required]
}
resource "google_secret_manager_secret_iam_member" "bootstrap" {
  project   = var.project_id
  secret_id = var.bootstrap_secret_id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${google_service_account.vm.email}"
}
resource "google_compute_firewall" "console" {
  project                 = var.project_id
  name                    = "${var.name}-console"
  network                 = google_compute_network.fort.name
  direction               = "INGRESS"
  source_ranges           = var.console_cidrs
  target_service_accounts = [google_service_account.vm.email]
  allow {
    protocol = "tcp"
    ports    = ["7451"]
  }
}
resource "google_compute_firewall" "ssh" {
  count                   = length(var.ssh_cidrs) == 0 ? 0 : 1
  project                 = var.project_id
  name                    = "${var.name}-ssh"
  network                 = google_compute_network.fort.name
  direction               = "INGRESS"
  source_ranges           = var.ssh_cidrs
  target_service_accounts = [google_service_account.vm.email]
  allow {
    protocol = "tcp"
    ports    = ["22"]
  }
}
resource "google_compute_address" "console" {
  project    = var.project_id
  name       = "${var.name}-ip"
  region     = var.region
  depends_on = [google_project_service.required]
}
module "bootstrap" {
  source         = "../shared"
  docker_version = var.docker_version
  config = {
    cloud          = "gcp"
    region         = var.region
    secret_id      = "projects/${var.project_id}/secrets/${var.bootstrap_secret_id}"
    secret_version = var.bootstrap_secret_version
    fort           = var.fort
  }
}
resource "google_compute_instance" "fort" {
  project             = var.project_id
  name                = var.name
  zone                = var.zone
  machine_type        = var.machine_type
  deletion_protection = true
  boot_disk {
    auto_delete = false
    initialize_params {
      image = "projects/ubuntu-os-cloud/global/images/${var.image_name}"
      size  = var.disk_size_gb
      type  = "pd-balanced"
    }
  }
  network_interface {
    subnetwork = google_compute_subnetwork.fort.id
    access_config {
      nat_ip = google_compute_address.console.address
    }
  }
  service_account {
    email  = google_service_account.vm.email
    scopes = ["https://www.googleapis.com/auth/cloud-platform"]
  }
  metadata = {
    startup-script         = module.bootstrap.script
    enable-oslogin         = "TRUE"
    block-project-ssh-keys = "TRUE"
  }
  shielded_instance_config {
    enable_secure_boot          = true
    enable_vtpm                 = true
    enable_integrity_monitoring = true
  }
  lifecycle {
    prevent_destroy = true
    precondition {
      condition     = startswith(var.zone, "${var.region}-")
      error_message = "zone must be inside region."
    }
  }
  depends_on = [google_secret_manager_secret_iam_member.bootstrap, google_compute_firewall.console]
}
resource "google_dns_record_set" "console" {
  count        = var.dns_zone_name == null ? 0 : 1
  project      = var.project_id
  managed_zone = var.dns_zone_name
  name         = "${var.fort.hostname}."
  type         = "A"
  ttl          = 300
  rrdatas      = [google_compute_address.console.address]
}
