variable "project_id" {
  description = "Existing billing-enabled GCP project."
  type        = string
}
variable "region" {
  description = "Region for the VM network, external address and optional DNS."
  type        = string
}
variable "zone" {
  description = "Zone within region; for example us-central1-a."
  type        = string
}
variable "subnet_cidr" {
  description = "IPv4 range for the new dedicated Fort subnet; avoid Docker's ranges."
  type        = string
  default     = "10.80.0.0/24"
  validation {
    condition     = can(cidrnetmask(var.subnet_cidr))
    error_message = "Supply a valid IPv4 subnet CIDR."
  }
}
variable "image_name" {
  description = "Pinned Ubuntu 24.04 amd64 image name in ubuntu-os-cloud, not an image family."
  type        = string
  validation {
    condition     = can(regex("^ubuntu-2404-noble-amd64-v[0-9]+$", var.image_name))
    error_message = "Use an exact ubuntu-2404-noble-amd64-vDATE image name."
  }
}
variable "machine_type" {
  description = "x86_64 VM size; 4 vCPU and 16 GiB to start."
  type        = string
  default     = "e2-standard-4"
}
variable "bootstrap_secret_id" {
  description = "Existing same-project secret name (not its value or full resource path)."
  type        = string
  validation {
    condition     = can(regex("^[A-Za-z0-9_-]{1,255}$", var.bootstrap_secret_id))
    error_message = "Use a Secret Manager secret name."
  }
}
variable "bootstrap_secret_version" {
  description = "Immutable numeric version of that secret; never latest."
  type        = string
  validation {
    condition     = can(regex("^[1-9][0-9]*$", var.bootstrap_secret_version))
    error_message = "Supply an exact numbered secret version."
  }
}
variable "dns_zone_name" {
  description = "Optional existing Cloud DNS public managed zone; null means manage DNS yourself."
  type        = string
  default     = null
}
